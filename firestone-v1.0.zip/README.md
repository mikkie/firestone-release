================== Firestone ===================


**Install & Start**
===================

1.Download and install the mongodb

2.Start the mongodb

3.Run bin/initData.bat

4.Run startup.bat

**Configure**
===================
visit http://localhost:5000

default username and passowrd is admin, 123456
