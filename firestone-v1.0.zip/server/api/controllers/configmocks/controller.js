"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.ConfigMockController = void 0;

var _configmock = _interopRequireDefault(require("../../services/configmock.service"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class ConfigMockController {
  getConfig(req, res) {
    _configmock.default.getConfig(req.params.accesstoken).then(r => {
      if (r) res.json(r);else res.json({});
    }, err => {
      res.json({
        error: err ? err.toString() : 'get config failed'
      });
    });
  }

  saveConfig(req, res) {
    _configmock.default.saveConfig(req.body.accesstoken, req.body.update).then(r => {
      if (r) {
        res.json(r);
      } else {
        _configmock.default.createConfig(req.body.accesstoken, req.body.update).then(config => {
          if (config) res.json(config);else res.json({});
        }, err => {
          res.json({
            error: err ? err.toString() : 'create config failed'
          });
        });
      }
    }, err => {
      res.json({
        error: err ? err.toString() : 'update config failed'
      });
    });
  }

}

exports.ConfigMockController = ConfigMockController;

var _default = new ConfigMockController();

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9hcGkvY29udHJvbGxlcnMvY29uZmlnbW9ja3MvY29udHJvbGxlci5qcyJdLCJuYW1lcyI6WyJDb25maWdNb2NrQ29udHJvbGxlciIsImdldENvbmZpZyIsInJlcSIsInJlcyIsImNvbmZpZ01vY2tTZXJ2aWNlIiwicGFyYW1zIiwiYWNjZXNzdG9rZW4iLCJ0aGVuIiwiciIsImpzb24iLCJlcnIiLCJlcnJvciIsInRvU3RyaW5nIiwic2F2ZUNvbmZpZyIsImJvZHkiLCJ1cGRhdGUiLCJjcmVhdGVDb25maWciLCJjb25maWciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7OztBQUVPLE1BQU1BLG9CQUFOLENBQTBCO0FBRTdCQyxFQUFBQSxTQUFTLENBQUNDLEdBQUQsRUFBTUMsR0FBTixFQUFXO0FBQ2hCQyx3QkFBa0JILFNBQWxCLENBQTRCQyxHQUFHLENBQUNHLE1BQUosQ0FBV0MsV0FBdkMsRUFBb0RDLElBQXBELENBQXlEQyxDQUFDLElBQUk7QUFDMUQsVUFBR0EsQ0FBSCxFQUFNTCxHQUFHLENBQUNNLElBQUosQ0FBU0QsQ0FBVCxFQUFOLEtBQ0tMLEdBQUcsQ0FBQ00sSUFBSixDQUFTLEVBQVQ7QUFDUixLQUhELEVBR0lDLEdBQUQsSUFBUztBQUNSUCxNQUFBQSxHQUFHLENBQUNNLElBQUosQ0FBUztBQUFDRSxRQUFBQSxLQUFLLEVBQUdELEdBQUcsR0FBR0EsR0FBRyxDQUFDRSxRQUFKLEVBQUgsR0FBbUI7QUFBL0IsT0FBVDtBQUNILEtBTEQ7QUFNSDs7QUFFREMsRUFBQUEsVUFBVSxDQUFDWCxHQUFELEVBQU1DLEdBQU4sRUFBVztBQUNqQkMsd0JBQWtCUyxVQUFsQixDQUE2QlgsR0FBRyxDQUFDWSxJQUFKLENBQVNSLFdBQXRDLEVBQW1ESixHQUFHLENBQUNZLElBQUosQ0FBU0MsTUFBNUQsRUFBb0VSLElBQXBFLENBQXlFQyxDQUFDLElBQUk7QUFDMUUsVUFBR0EsQ0FBSCxFQUFLO0FBQ0RMLFFBQUFBLEdBQUcsQ0FBQ00sSUFBSixDQUFTRCxDQUFUO0FBQ0gsT0FGRCxNQUdJO0FBQ0FKLDRCQUFrQlksWUFBbEIsQ0FBK0JkLEdBQUcsQ0FBQ1ksSUFBSixDQUFTUixXQUF4QyxFQUFxREosR0FBRyxDQUFDWSxJQUFKLENBQVNDLE1BQTlELEVBQXNFUixJQUF0RSxDQUEyRVUsTUFBTSxJQUFJO0FBQ2pGLGNBQUdBLE1BQUgsRUFBV2QsR0FBRyxDQUFDTSxJQUFKLENBQVNRLE1BQVQsRUFBWCxLQUNLZCxHQUFHLENBQUNNLElBQUosQ0FBUyxFQUFUO0FBQ1IsU0FIRCxFQUdJQyxHQUFELElBQVM7QUFDUlAsVUFBQUEsR0FBRyxDQUFDTSxJQUFKLENBQVM7QUFBQ0UsWUFBQUEsS0FBSyxFQUFHRCxHQUFHLEdBQUdBLEdBQUcsQ0FBQ0UsUUFBSixFQUFILEdBQW9CO0FBQWhDLFdBQVQ7QUFDSCxTQUxEO0FBTUg7QUFDSixLQVpELEVBWUlGLEdBQUQsSUFBUztBQUNSUCxNQUFBQSxHQUFHLENBQUNNLElBQUosQ0FBUztBQUFDRSxRQUFBQSxLQUFLLEVBQUdELEdBQUcsR0FBR0EsR0FBRyxDQUFDRSxRQUFKLEVBQUgsR0FBb0I7QUFBaEMsT0FBVDtBQUNILEtBZEQ7QUFlSDs7QUEzQjRCOzs7O2VBK0JsQixJQUFJWixvQkFBSixFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGNvbmZpZ01vY2tTZXJ2aWNlIGZyb20gJy4uLy4uL3NlcnZpY2VzL2NvbmZpZ21vY2suc2VydmljZSdcclxuXHJcbmV4cG9ydCBjbGFzcyBDb25maWdNb2NrQ29udHJvbGxlcntcclxuXHJcbiAgICBnZXRDb25maWcocmVxLCByZXMpIHtcclxuICAgICAgICBjb25maWdNb2NrU2VydmljZS5nZXRDb25maWcocmVxLnBhcmFtcy5hY2Nlc3N0b2tlbikudGhlbihyID0+IHtcclxuICAgICAgICAgICAgaWYocikgcmVzLmpzb24ocik7XHJcbiAgICAgICAgICAgIGVsc2UgcmVzLmpzb24oe30pO1xyXG4gICAgICAgIH0sIChlcnIpID0+IHtcclxuICAgICAgICAgICAgcmVzLmpzb24oe2Vycm9yIDogZXJyID8gZXJyLnRvU3RyaW5nKCk6ICdnZXQgY29uZmlnIGZhaWxlZCd9KTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBzYXZlQ29uZmlnKHJlcSwgcmVzKSB7XHJcbiAgICAgICAgY29uZmlnTW9ja1NlcnZpY2Uuc2F2ZUNvbmZpZyhyZXEuYm9keS5hY2Nlc3N0b2tlbiwgcmVxLmJvZHkudXBkYXRlKS50aGVuKHIgPT4ge1xyXG4gICAgICAgICAgICBpZihyKXtcclxuICAgICAgICAgICAgICAgIHJlcy5qc29uKHIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgICAgICBjb25maWdNb2NrU2VydmljZS5jcmVhdGVDb25maWcocmVxLmJvZHkuYWNjZXNzdG9rZW4sIHJlcS5ib2R5LnVwZGF0ZSkudGhlbihjb25maWcgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGNvbmZpZykgcmVzLmpzb24oY29uZmlnKVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgcmVzLmpzb24oe30pO1xyXG4gICAgICAgICAgICAgICAgfSwgKGVycikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlcy5qc29uKHtlcnJvciA6IGVyciA/IGVyci50b1N0cmluZygpIDogJ2NyZWF0ZSBjb25maWcgZmFpbGVkJ30pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gICBcclxuICAgICAgICB9LCAoZXJyKSA9PiB7XHJcbiAgICAgICAgICAgIHJlcy5qc29uKHtlcnJvciA6IGVyciA/IGVyci50b1N0cmluZygpIDogJ3VwZGF0ZSBjb25maWcgZmFpbGVkJ30pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbmV3IENvbmZpZ01vY2tDb250cm9sbGVyKCkiXX0=