"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.FireStoneRockController = void 0;

var _firestonerock = _interopRequireDefault(require("../../services/firestonerock.service"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class FireStoneRockController {
  create(req, res) {
    _firestonerock.default.createNewFirerock(req.body.codes, req.body.tradeId).then(r => {
      r ? res.json(r) : res.json({});
    }, err => {
      res.json({
        "error": err ? err.toString() : 'failed to create new firerock'
      });
    });
  }

}

exports.FireStoneRockController = FireStoneRockController;

var _default = new FireStoneRockController();

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlcnZlci9hcGkvY29udHJvbGxlcnMvZmlyZXN0b25lcm9jay9jb250cm9sbGVyLmpzIl0sIm5hbWVzIjpbIkZpcmVTdG9uZVJvY2tDb250cm9sbGVyIiwiY3JlYXRlIiwicmVxIiwicmVzIiwiZmlyZXN0b25lcm9ja1NlcnZpY2UiLCJjcmVhdGVOZXdGaXJlcm9jayIsImJvZHkiLCJjb2RlcyIsInRyYWRlSWQiLCJ0aGVuIiwiciIsImpzb24iLCJlcnIiLCJ0b1N0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBOzs7O0FBRU8sTUFBTUEsdUJBQU4sQ0FBNkI7QUFFaENDLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBRCxFQUFNQyxHQUFOLEVBQVU7QUFDWkMsMkJBQXFCQyxpQkFBckIsQ0FBdUNILEdBQUcsQ0FBQ0ksSUFBSixDQUFTQyxLQUFoRCxFQUF1REwsR0FBRyxDQUFDSSxJQUFKLENBQVNFLE9BQWhFLEVBQXlFQyxJQUF6RSxDQUE4RUMsQ0FBQyxJQUFJO0FBQy9FQSxNQUFBQSxDQUFDLEdBQUdQLEdBQUcsQ0FBQ1EsSUFBSixDQUFTRCxDQUFULENBQUgsR0FBaUJQLEdBQUcsQ0FBQ1EsSUFBSixDQUFTLEVBQVQsQ0FBbEI7QUFDSCxLQUZELEVBRUdDLEdBQUcsSUFBSTtBQUNOVCxNQUFBQSxHQUFHLENBQUNRLElBQUosQ0FBUztBQUFDLGlCQUFVQyxHQUFHLEdBQUdBLEdBQUcsQ0FBQ0MsUUFBSixFQUFILEdBQW9CO0FBQWxDLE9BQVQ7QUFDSCxLQUpEO0FBS0g7O0FBUitCOzs7O2VBWXJCLElBQUliLHVCQUFKLEUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZmlyZXN0b25lcm9ja1NlcnZpY2UgZnJvbSAnLi4vLi4vc2VydmljZXMvZmlyZXN0b25lcm9jay5zZXJ2aWNlJ1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpcmVTdG9uZVJvY2tDb250cm9sbGVye1xyXG5cclxuICAgIGNyZWF0ZShyZXEsIHJlcyl7XHJcbiAgICAgICAgZmlyZXN0b25lcm9ja1NlcnZpY2UuY3JlYXRlTmV3RmlyZXJvY2socmVxLmJvZHkuY29kZXMsIHJlcS5ib2R5LnRyYWRlSWQpLnRoZW4ociA9PiB7XHJcbiAgICAgICAgICAgIHIgPyByZXMuanNvbihyKSA6IHJlcy5qc29uKHt9KTtcclxuICAgICAgICB9LCBlcnIgPT4ge1xyXG4gICAgICAgICAgICByZXMuanNvbih7XCJlcnJvclwiIDogZXJyID8gZXJyLnRvU3RyaW5nKCkgOiAnZmFpbGVkIHRvIGNyZWF0ZSBuZXcgZmlyZXJvY2snfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBuZXcgRmlyZVN0b25lUm9ja0NvbnRyb2xsZXIoKSJdfQ==