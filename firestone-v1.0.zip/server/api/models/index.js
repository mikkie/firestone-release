"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.connectDB = void 0;

var _mongoose = _interopRequireDefault(require("mongoose"));

var _user = _interopRequireDefault(require("./user"));

var _configMock = _interopRequireDefault(require("./configMock"));

var _mockTrade = _interopRequireDefault(require("./mockTrade"));

var _strategy = _interopRequireDefault(require("./strategy"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const connectDB = () => {
  return _mongoose.default.connect(process.env.MONGO_URL);
};

exports.connectDB = connectDB;
const models = {
  User: _user.default,
  ConfigMock: _configMock.default,
  MockTrade: _mockTrade.default,
  Strategy: _strategy.default
};
var _default = models;
exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NlcnZlci9hcGkvbW9kZWxzL2luZGV4LmpzIl0sIm5hbWVzIjpbImNvbm5lY3REQiIsIm1vbmdvb3NlIiwiY29ubmVjdCIsInByb2Nlc3MiLCJlbnYiLCJNT05HT19VUkwiLCJtb2RlbHMiLCJVc2VyIiwiQ29uZmlnTW9jayIsIk1vY2tUcmFkZSIsIlN0cmF0ZWd5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7O0FBRUE7O0FBQ0E7O0FBQ0E7O0FBQ0E7Ozs7QUFFQSxNQUFNQSxTQUFTLEdBQUcsTUFBTTtBQUNwQixTQUFPQyxrQkFBU0MsT0FBVCxDQUFpQkMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLFNBQTdCLENBQVA7QUFDSCxDQUZEOzs7QUFJQSxNQUFNQyxNQUFNLEdBQUc7QUFBRUMsRUFBQUEsSUFBSSxFQUFKQSxhQUFGO0FBQVFDLEVBQUFBLFVBQVUsRUFBVkEsbUJBQVI7QUFBb0JDLEVBQUFBLFNBQVMsRUFBVEEsa0JBQXBCO0FBQStCQyxFQUFBQSxRQUFRLEVBQVJBO0FBQS9CLENBQWY7ZUFHZUosTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSdcclxuXHJcbmltcG9ydCBVc2VyIGZyb20gJy4vdXNlcidcclxuaW1wb3J0IENvbmZpZ01vY2sgZnJvbSAnLi9jb25maWdNb2NrJ1xyXG5pbXBvcnQgTW9ja1RyYWRlIGZyb20gJy4vbW9ja1RyYWRlJ1xyXG5pbXBvcnQgU3RyYXRlZ3kgZnJvbSAnLi9zdHJhdGVneSdcclxuXHJcbmNvbnN0IGNvbm5lY3REQiA9ICgpID0+IHtcclxuICAgIHJldHVybiBtb25nb29zZS5jb25uZWN0KHByb2Nlc3MuZW52Lk1PTkdPX1VSTCk7XHJcbn07XHJcblxyXG5jb25zdCBtb2RlbHMgPSB7IFVzZXIsIENvbmZpZ01vY2ssIE1vY2tUcmFkZSwgU3RyYXRlZ3kgfTtcclxuXHJcbmV4cG9ydCB7IGNvbm5lY3REQiB9O1xyXG5leHBvcnQgZGVmYXVsdCBtb2RlbHM7XHJcbiJdfQ==