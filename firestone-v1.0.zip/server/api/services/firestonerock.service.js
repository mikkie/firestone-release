"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _logger = _interopRequireDefault(require("../../common/logger"));

var _child_process = _interopRequireDefault(require("child_process"));

var _util = _interopRequireDefault(require("util"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class FireStoneRockService {
  constructor() {
    this.exec = _util.default.promisify(_child_process.default.exec);
  }

  async createNewFirerock(codes, tradeId) {
    let msg = `start the firestonerock service code=${codes}, tradeId=${tradeId}`;

    _logger.default.info(msg);

    this.exec(`shell\\runfirerock ${tradeId}`);
    return new Promise((resolve, reject) => {
      resolve({
        'success': msg
      });
    });
  }

}

var _default = new FireStoneRockService();

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NlcnZlci9hcGkvc2VydmljZXMvZmlyZXN0b25lcm9jay5zZXJ2aWNlLmpzIl0sIm5hbWVzIjpbIkZpcmVTdG9uZVJvY2tTZXJ2aWNlIiwiY29uc3RydWN0b3IiLCJleGVjIiwidXRpbCIsInByb21pc2lmeSIsImNoaWxkX3Byb2Nlc3MiLCJjcmVhdGVOZXdGaXJlcm9jayIsImNvZGVzIiwidHJhZGVJZCIsIm1zZyIsImwiLCJpbmZvIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7QUFDQTs7QUFDQTs7OztBQUVBLE1BQU1BLG9CQUFOLENBQTBCO0FBRXRCQyxFQUFBQSxXQUFXLEdBQUU7QUFDVCxTQUFLQyxJQUFMLEdBQVlDLGNBQUtDLFNBQUwsQ0FBZUMsdUJBQWNILElBQTdCLENBQVo7QUFDSDs7QUFFRCxRQUFNSSxpQkFBTixDQUF3QkMsS0FBeEIsRUFBK0JDLE9BQS9CLEVBQXVDO0FBQ25DLFFBQUlDLEdBQUcsR0FBSSx3Q0FBdUNGLEtBQU0sYUFBWUMsT0FBUSxFQUE1RTs7QUFDQUUsb0JBQUVDLElBQUYsQ0FBT0YsR0FBUDs7QUFDQSxTQUFLUCxJQUFMLENBQVcsc0JBQXFCTSxPQUFRLEVBQXhDO0FBQ0EsV0FBTyxJQUFJSSxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ3BDRCxNQUFBQSxPQUFPLENBQUM7QUFBQyxtQkFBWUo7QUFBYixPQUFELENBQVA7QUFDSCxLQUZNLENBQVA7QUFHSDs7QUFicUI7O2VBaUJYLElBQUlULG9CQUFKLEUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbCBmcm9tICcuLi8uLi9jb21tb24vbG9nZ2VyJztcclxuaW1wb3J0IGNoaWxkX3Byb2Nlc3MgZnJvbSAnY2hpbGRfcHJvY2Vzcyc7XHJcbmltcG9ydCB1dGlsIGZyb20gJ3V0aWwnXHJcblxyXG5jbGFzcyBGaXJlU3RvbmVSb2NrU2VydmljZXtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcigpe1xyXG4gICAgICAgIHRoaXMuZXhlYyA9IHV0aWwucHJvbWlzaWZ5KGNoaWxkX3Byb2Nlc3MuZXhlYylcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBjcmVhdGVOZXdGaXJlcm9jayhjb2RlcywgdHJhZGVJZCl7XHJcbiAgICAgICAgbGV0IG1zZyA9IGBzdGFydCB0aGUgZmlyZXN0b25lcm9jayBzZXJ2aWNlIGNvZGU9JHtjb2Rlc30sIHRyYWRlSWQ9JHt0cmFkZUlkfWA7XHJcbiAgICAgICAgbC5pbmZvKG1zZyk7XHJcbiAgICAgICAgdGhpcy5leGVjKGBzaGVsbFxcXFxydW5maXJlcm9jayAke3RyYWRlSWR9YCk7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgcmVzb2x2ZSh7J3N1Y2Nlc3MnIDogbXNnfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBuZXcgRmlyZVN0b25lUm9ja1NlcnZpY2UoKSJdfQ==