"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _express = _interopRequireDefault(require("express"));

var path = _interopRequireWildcard(require("path"));

var bodyParser = _interopRequireWildcard(require("body-parser"));

var http = _interopRequireWildcard(require("http"));

var os = _interopRequireWildcard(require("os"));

var _cookieParser = _interopRequireDefault(require("cookie-parser"));

var _cors = _interopRequireDefault(require("cors"));

var _nodeSchedule = _interopRequireDefault(require("node-schedule"));

var _child_process = _interopRequireDefault(require("child_process"));

var _util = _interopRequireDefault(require("util"));

var _swagger = _interopRequireDefault(require("./swagger"));

var _logger = _interopRequireDefault(require("./logger"));

var _models = require("../api/models");

var _configmock = _interopRequireDefault(require("../api/services/configmock.service"));

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const app = new _express.default();

class ExpressServer {
  constructor() {
    const root = path.normalize(`${__dirname}/../..`);
    app.set('appPath', `${root}client`);
    app.use(bodyParser.json({
      limit: process.env.REQUEST_LIMIT || '100kb'
    }));
    app.use(bodyParser.urlencoded({
      extended: true,
      limit: process.env.REQUEST_LIMIT || '100kb'
    }));
    app.use((0, _cookieParser.default)(process.env.SESSION_SECRET));
    app.use(_express.default.static(`${root}/public`));
    app.use((0, _cors.default)());
  }

  router(routes) {
    (0, _swagger.default)(app, routes);
    return this;
  }

  init() {
    _configmock.default.clearCurBuyNum().then(r => {
      _logger.default.info('reset all mock config curBuyNum = 0, done');
    }, err => {
      _logger.default.error(`reset all mock config curBuyNum = 0, failed = ${err}`);
    });

    let exec = _util.default.promisify(_child_process.default.exec);

    exec('shell\\runfirestone');

    _logger.default.info('start the firestone service');
  }

  listen(port = process.env.PORT) {
    (0, _models.connectDB)().then(async () => {
      const welcome = p => () => _logger.default.info(`up and running in ${process.env.NODE_ENV || 'development'} @: ${os.hostname()} on port: ${p}}`);

      http.createServer(app).listen(port, welcome(port));

      _nodeSchedule.default.scheduleJob('0 0 9 ? * 1-5', () => {
        this.init();
      });

      if (new Date().getHours() >= 9) {
        this.init();
      }
    });
    return app;
  }

}

exports.default = ExpressServer;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NlcnZlci9jb21tb24vc2VydmVyLmpzIl0sIm5hbWVzIjpbImFwcCIsIkV4cHJlc3MiLCJFeHByZXNzU2VydmVyIiwiY29uc3RydWN0b3IiLCJyb290IiwicGF0aCIsIm5vcm1hbGl6ZSIsIl9fZGlybmFtZSIsInNldCIsInVzZSIsImJvZHlQYXJzZXIiLCJqc29uIiwibGltaXQiLCJwcm9jZXNzIiwiZW52IiwiUkVRVUVTVF9MSU1JVCIsInVybGVuY29kZWQiLCJleHRlbmRlZCIsIlNFU1NJT05fU0VDUkVUIiwic3RhdGljIiwicm91dGVyIiwicm91dGVzIiwiaW5pdCIsImNvbmZpZ01vY2tTZXJ2aWNlIiwiY2xlYXJDdXJCdXlOdW0iLCJ0aGVuIiwiciIsImwiLCJpbmZvIiwiZXJyIiwiZXJyb3IiLCJleGVjIiwidXRpbCIsInByb21pc2lmeSIsImNoaWxkX3Byb2Nlc3MiLCJsaXN0ZW4iLCJwb3J0IiwiUE9SVCIsIndlbGNvbWUiLCJwIiwiTk9ERV9FTlYiLCJvcyIsImhvc3RuYW1lIiwiaHR0cCIsImNyZWF0ZVNlcnZlciIsInNjaGVkdWxlIiwic2NoZWR1bGVKb2IiLCJEYXRlIiwiZ2V0SG91cnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFFQTs7QUFFQTs7QUFDQTs7QUFDQTs7Ozs7O0FBRUEsTUFBTUEsR0FBRyxHQUFHLElBQUlDLGdCQUFKLEVBQVo7O0FBRWUsTUFBTUMsYUFBTixDQUFvQjtBQUNqQ0MsRUFBQUEsV0FBVyxHQUFHO0FBQ1osVUFBTUMsSUFBSSxHQUFHQyxJQUFJLENBQUNDLFNBQUwsQ0FBZ0IsR0FBRUMsU0FBVSxRQUE1QixDQUFiO0FBQ0FQLElBQUFBLEdBQUcsQ0FBQ1EsR0FBSixDQUFRLFNBQVIsRUFBb0IsR0FBRUosSUFBSyxRQUEzQjtBQUNBSixJQUFBQSxHQUFHLENBQUNTLEdBQUosQ0FBUUMsVUFBVSxDQUFDQyxJQUFYLENBQWdCO0FBQUVDLE1BQUFBLEtBQUssRUFBRUMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLGFBQVosSUFBNkI7QUFBdEMsS0FBaEIsQ0FBUjtBQUNBZixJQUFBQSxHQUFHLENBQUNTLEdBQUosQ0FBUUMsVUFBVSxDQUFDTSxVQUFYLENBQXNCO0FBQUVDLE1BQUFBLFFBQVEsRUFBRSxJQUFaO0FBQWtCTCxNQUFBQSxLQUFLLEVBQUVDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxhQUFaLElBQTZCO0FBQXRELEtBQXRCLENBQVI7QUFDQWYsSUFBQUEsR0FBRyxDQUFDUyxHQUFKLENBQVEsMkJBQWFJLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSSxjQUF6QixDQUFSO0FBQ0FsQixJQUFBQSxHQUFHLENBQUNTLEdBQUosQ0FBUVIsaUJBQVFrQixNQUFSLENBQWdCLEdBQUVmLElBQUssU0FBdkIsQ0FBUjtBQUNBSixJQUFBQSxHQUFHLENBQUNTLEdBQUosQ0FBUSxvQkFBUjtBQUNEOztBQUVEVyxFQUFBQSxNQUFNLENBQUNDLE1BQUQsRUFBUztBQUNiLDBCQUFXckIsR0FBWCxFQUFnQnFCLE1BQWhCO0FBRUEsV0FBTyxJQUFQO0FBQ0Q7O0FBR0RDLEVBQUFBLElBQUksR0FBRTtBQUNKQyx3QkFBa0JDLGNBQWxCLEdBQW1DQyxJQUFuQyxDQUF3Q0MsQ0FBQyxJQUFJO0FBQzNDQyxzQkFBRUMsSUFBRixDQUFPLDJDQUFQO0FBQ0QsS0FGRCxFQUVJQyxHQUFELElBQVM7QUFDVkYsc0JBQUVHLEtBQUYsQ0FBUyxpREFBZ0RELEdBQUksRUFBN0Q7QUFDRCxLQUpEOztBQUtBLFFBQUlFLElBQUksR0FBR0MsY0FBS0MsU0FBTCxDQUFlQyx1QkFBY0gsSUFBN0IsQ0FBWDs7QUFDQUEsSUFBQUEsSUFBSSxDQUFDLHFCQUFELENBQUo7O0FBQ0FKLG9CQUFFQyxJQUFGLENBQU8sNkJBQVA7QUFDRDs7QUFHRE8sRUFBQUEsTUFBTSxDQUFDQyxJQUFJLEdBQUd2QixPQUFPLENBQUNDLEdBQVIsQ0FBWXVCLElBQXBCLEVBQTBCO0FBQzlCLDZCQUFZWixJQUFaLENBQWlCLFlBQVc7QUFDMUIsWUFBTWEsT0FBTyxHQUFHQyxDQUFDLElBQUksTUFBTVosZ0JBQUVDLElBQUYsQ0FBUSxxQkFBb0JmLE9BQU8sQ0FBQ0MsR0FBUixDQUFZMEIsUUFBWixJQUF3QixhQUFjLE9BQU1DLEVBQUUsQ0FBQ0MsUUFBSCxFQUFjLGFBQVlILENBQUUsR0FBcEcsQ0FBM0I7O0FBQ0FJLE1BQUFBLElBQUksQ0FBQ0MsWUFBTCxDQUFrQjVDLEdBQWxCLEVBQXVCbUMsTUFBdkIsQ0FBOEJDLElBQTlCLEVBQW9DRSxPQUFPLENBQUNGLElBQUQsQ0FBM0M7O0FBQ0FTLDRCQUFTQyxXQUFULENBQXFCLGVBQXJCLEVBQXNDLE1BQU07QUFDMUMsYUFBS3hCLElBQUw7QUFDRCxPQUZEOztBQUdBLFVBQUcsSUFBSXlCLElBQUosR0FBV0MsUUFBWCxNQUF5QixDQUE1QixFQUE4QjtBQUM1QixhQUFLMUIsSUFBTDtBQUNEO0FBQ0YsS0FURDtBQVVBLFdBQU90QixHQUFQO0FBQ0Q7O0FBMUNnQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBFeHByZXNzIGZyb20gJ2V4cHJlc3MnO1xuaW1wb3J0ICogYXMgcGF0aCBmcm9tICdwYXRoJztcbmltcG9ydCAqIGFzIGJvZHlQYXJzZXIgZnJvbSAnYm9keS1wYXJzZXInO1xuaW1wb3J0ICogYXMgaHR0cCBmcm9tICdodHRwJztcbmltcG9ydCAqIGFzIG9zIGZyb20gJ29zJztcbmltcG9ydCBjb29raWVQYXJzZXIgZnJvbSAnY29va2llLXBhcnNlcic7XG5pbXBvcnQgY29ycyBmcm9tICdjb3JzJ1xuaW1wb3J0IHNjaGVkdWxlIGZyb20gJ25vZGUtc2NoZWR1bGUnXG5pbXBvcnQgY2hpbGRfcHJvY2VzcyBmcm9tICdjaGlsZF9wcm9jZXNzJztcbmltcG9ydCB1dGlsIGZyb20gJ3V0aWwnXG5cbmltcG9ydCBzd2FnZ2VyaWZ5IGZyb20gJy4vc3dhZ2dlcic7XG5cbmltcG9ydCBsIGZyb20gJy4vbG9nZ2VyJztcbmltcG9ydCB7IGNvbm5lY3REQiB9IGZyb20gJy4uL2FwaS9tb2RlbHMnO1xuaW1wb3J0IGNvbmZpZ01vY2tTZXJ2aWNlIGZyb20gJy4uL2FwaS9zZXJ2aWNlcy9jb25maWdtb2NrLnNlcnZpY2UnXG5cbmNvbnN0IGFwcCA9IG5ldyBFeHByZXNzKCk7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEV4cHJlc3NTZXJ2ZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBjb25zdCByb290ID0gcGF0aC5ub3JtYWxpemUoYCR7X19kaXJuYW1lfS8uLi8uLmApO1xuICAgIGFwcC5zZXQoJ2FwcFBhdGgnLCBgJHtyb290fWNsaWVudGApO1xuICAgIGFwcC51c2UoYm9keVBhcnNlci5qc29uKHsgbGltaXQ6IHByb2Nlc3MuZW52LlJFUVVFU1RfTElNSVQgfHwgJzEwMGtiJyB9KSk7XG4gICAgYXBwLnVzZShib2R5UGFyc2VyLnVybGVuY29kZWQoeyBleHRlbmRlZDogdHJ1ZSwgbGltaXQ6IHByb2Nlc3MuZW52LlJFUVVFU1RfTElNSVQgfHwgJzEwMGtiJyB9KSk7XG4gICAgYXBwLnVzZShjb29raWVQYXJzZXIocHJvY2Vzcy5lbnYuU0VTU0lPTl9TRUNSRVQpKTtcbiAgICBhcHAudXNlKEV4cHJlc3Muc3RhdGljKGAke3Jvb3R9L3B1YmxpY2ApKTtcbiAgICBhcHAudXNlKGNvcnMoKSk7XG4gIH1cblxuICByb3V0ZXIocm91dGVzKSB7XG4gICAgc3dhZ2dlcmlmeShhcHAsIHJvdXRlcyk7XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG5cbiAgaW5pdCgpe1xuICAgIGNvbmZpZ01vY2tTZXJ2aWNlLmNsZWFyQ3VyQnV5TnVtKCkudGhlbihyID0+IHtcbiAgICAgIGwuaW5mbygncmVzZXQgYWxsIG1vY2sgY29uZmlnIGN1ckJ1eU51bSA9IDAsIGRvbmUnKTtcbiAgICB9LCAoZXJyKSA9PiB7XG4gICAgICBsLmVycm9yKGByZXNldCBhbGwgbW9jayBjb25maWcgY3VyQnV5TnVtID0gMCwgZmFpbGVkID0gJHtlcnJ9YCk7XG4gICAgfSk7XG4gICAgbGV0IGV4ZWMgPSB1dGlsLnByb21pc2lmeShjaGlsZF9wcm9jZXNzLmV4ZWMpXG4gICAgZXhlYygnc2hlbGxcXFxccnVuZmlyZXN0b25lJyk7XG4gICAgbC5pbmZvKCdzdGFydCB0aGUgZmlyZXN0b25lIHNlcnZpY2UnKTtcbiAgfVxuXG5cbiAgbGlzdGVuKHBvcnQgPSBwcm9jZXNzLmVudi5QT1JUKSB7XG4gICAgY29ubmVjdERCKCkudGhlbihhc3luYyAoKT0+IHtcbiAgICAgIGNvbnN0IHdlbGNvbWUgPSBwID0+ICgpID0+IGwuaW5mbyhgdXAgYW5kIHJ1bm5pbmcgaW4gJHtwcm9jZXNzLmVudi5OT0RFX0VOViB8fCAnZGV2ZWxvcG1lbnQnfSBAOiAke29zLmhvc3RuYW1lKCl9IG9uIHBvcnQ6ICR7cH19YCk7XG4gICAgICBodHRwLmNyZWF0ZVNlcnZlcihhcHApLmxpc3Rlbihwb3J0LCB3ZWxjb21lKHBvcnQpKTtcbiAgICAgIHNjaGVkdWxlLnNjaGVkdWxlSm9iKCcwIDAgOSA/ICogMS01JywgKCkgPT4ge1xuICAgICAgICB0aGlzLmluaXQoKTtcbiAgICAgIH0pO1xuICAgICAgaWYobmV3IERhdGUoKS5nZXRIb3VycygpID49IDkpe1xuICAgICAgICB0aGlzLmluaXQoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gYXBwO1xuICB9XG59XG4iXX0=