"use strict";

var _customEnv = _interopRequireDefault(require("custom-env"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_customEnv.default.env(true);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NlcnZlci9jb21tb24vZW52LmpzIl0sIm5hbWVzIjpbImN1c3RvbUVudiIsImVudiJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7OztBQUVBQSxtQkFBVUMsR0FBVixDQUFjLElBQWQiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgY3VzdG9tRW52IGZyb20gJ2N1c3RvbS1lbnYnO1xuXG5jdXN0b21FbnYuZW52KHRydWUpO1xuIl19